/**
 *
 * @author sebtr
 */
import java.util.*;

public class Juego {

    // Enumeraciones para palos y valores ============================================
    enum Palo {
        CORAZONES, DIAMANTES, PICAS, TREBOLES
    }

    enum Valor {
        A(1), DOS(2), TRES(3), CUATRO(4), CINCO(5), SEIS(6), SIETE(7), OCHO(8), NUEVE(9), DIEZ(10),
        J(10), Q(10), K(10);
        int puntos;

        Valor(int p) {
            this.puntos = p;
        }

        int getPuntos() {
            return puntos;
        }
    }

    // Carta ============================================================================
    static class Carta {

        Valor valor;
        Palo palo;

        Carta(Valor valor, Palo palo) {
            this.valor = valor;
            this.palo = palo;
        }

        public String toString() {
            return valor + " de " + palo;
        }
    }

    // Lista enlazada para baraja ========================================================
    static class NodoCarta {

        Carta carta;
        NodoCarta siguiente;

        NodoCarta(Carta carta) {
            this.carta = carta;
        }
    }
    
    // Baraja ==============================================================================
    static class Baraja {

        NodoCarta cabeza;

        void agregarCarta(Carta carta) {
            NodoCarta nuevo = new NodoCarta(carta);
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
        }

        Carta robarCarta() {
            if (cabeza == null) {
                return null;
            }
            Carta c = cabeza.carta;
            cabeza = cabeza.siguiente;
            return c;
        }

        void mezclar() {
            List<Carta> cartas = new ArrayList<>();
            while (cabeza != null) {
                cartas.add(robarCarta());
            }
            Collections.shuffle(cartas);
            for (Carta c : cartas) {
                agregarCarta(c);
            }
        }
    }

    // Árbol binario para decisiones del dealer ============================================
    static class NodoDecision {

        int valor;
        String accion;
        NodoDecision izq, der;

        NodoDecision(int valor, String accion) {
            this.valor = valor;
            this.accion = accion;
        }
    }

    static NodoDecision ArbolDecision() {
        NodoDecision raiz = new NodoDecision(17, "Plantarse");
        raiz.izq = new NodoDecision(0, "Pedir");
        return raiz;
    }

    static String decidirDealer(NodoDecision nodo, int puntaje) {
        return (puntaje < nodo.valor) ? nodo.izq.accion : nodo.accion;
    }

    // Jugador =============================================================================
    static class Jugador {

        String nombre;
        List<Carta> mano = new ArrayList<>();

        int puntaje() {
            int total = 0;
            for (Carta c : mano) {
                total += c.valor.getPuntos();
            }
            return total;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Baraja baraja = new Baraja();
        Stack<Carta> historial = new Stack<>();
        Queue<String> turnos = new LinkedList<>();
        HashMap<String, Jugador> jugadores = new HashMap<>();

        // Construir baraja ===============================================================
        for (Palo palo : Palo.values()) {
            for (Valor valor : Valor.values()) {
                baraja.agregarCarta(new Carta(valor, palo));
            }
        }
        baraja.mezclar();

        System.out.println("Hola vamos a jugar black jack 21 \nIngresa tu nombre: ");
        String nombre = sc.nextLine();

        Jugador jugador = new Jugador();
        jugador.nombre = nombre;
        Jugador dealer = new Jugador();
        dealer.nombre = "Dealer";

        jugadores.put(nombre, jugador);
        jugadores.put("Dealer", dealer);

        turnos.add(nombre);
        turnos.add("Dealer");

        // repartir dos cartas =================================================================
        for (Jugador j : jugadores.values()) {
            j.mano.add(baraja.robarCarta());
            j.mano.add(baraja.robarCarta());
        }

        NodoDecision arbol = ArbolDecision();

        while (!turnos.isEmpty()) {
            String turno = turnos.poll();
            Jugador actual = jugadores.get(turno);
            System.out.println("\nTurno de: " + turno);
            mostrarMano(actual);

            if (!turno.equals("Dealer")) {
                while (true) {
                    System.out.println("¿Desea otra carta? (s/n): ");
                    String resp = sc.nextLine();
                    if (resp.equalsIgnoreCase("s")) {
                        Carta nueva = baraja.robarCarta();
                        actual.mano.add(nueva);
                        historial.push(nueva);
                        mostrarMano(actual);
                        if (actual.puntaje() > 21) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
            } else {
                while (true) {
                    int puntaje = actual.puntaje();
                    String accion = decidirDealer(arbol, puntaje);
                    if (accion.equals("Pedir")) {
                        System.out.println("El dealer toma una carta...");
                        Carta nueva = baraja.robarCarta();
                        actual.mano.add(nueva);
                        historial.push(nueva);
                    } else {
                        System.out.println("El dealer se planta.");
                        break;
                    }
                }
            }
        }

        // Resultados ======================================================================
        System.out.println("\n-*-*-*-*-*- RESULTADOS -*-*-*-*-*-");
        for (Jugador j : jugadores.values()) {
            mostrarMano(j);
        }

        int pj = jugador.puntaje();
        int pd = dealer.puntaje();
        if ((pj > pd && pj <= 21) || (pd > 21 && pj <= 21)) {
            System.out.println("\n" + jugador.nombre + " gana! 🎉");
        } else if (pj == pd) {
            System.out.println("\nEmpate.");
        } else {
            System.out.println("\nDealer gana.");
        }
    }

    static void mostrarMano(Jugador j) {
        System.out.println(j.nombre + " tiene:");
        for (Carta c : j.mano) {
            System.out.println("  " + c);
        }
        System.out.println("Puntaje: " + j.puntaje());
    }
}
