/**
 *
 * @author sebtr
 */
import javax.swing.*;
import java.awt.*;
//import java.awt.event.*;
import java.util.*;

public class Juego_visual extends JFrame {

    enum Palo {
        CORAZONES, DIAMANTES, PICAS, TREBOLES
    }

    enum Valor {
        A(1), DOS(2), TRES(3), CUATRO(4), CINCO(5), SEIS(6), SIETE(7), OCHO(8), NUEVE(9), DIEZ(10),
        J(10), Q(10), K(10);
        int puntos;

        Valor(int p) {
            this.puntos = p;
        }

        int getPuntos() {
            return puntos;
        }
    }

    // Carta ============================================================================
    static class Carta {

        Valor valor;
        Palo palo;

        Carta(Valor valor, Palo palo) {
            this.valor = valor;
            this.palo = palo;
        }

        public String toString() {
            return valor + " de " + palo;
        }
    }

    // Jugador ============================================================================
    static class Jugador {

        String nombre;
        ArrayList<Carta> mano = new ArrayList<>();

        int puntaje() {
            int total = 0;
            for (Carta c : mano) {
                total += c.valor.getPuntos();
            }
            return total;
        }
    }
    
    // Árbol binario para decisiones del dealer ============================================
    static class NodoDecision {

        int valor;
        String accion;
        NodoDecision izq, der;

        NodoDecision(int valor, String accion) {
            this.valor = valor;
            this.accion = accion;
        }
    }

    static NodoDecision ArbolDecision() {
        NodoDecision raiz = new NodoDecision(17, "Plantarse");
        raiz.izq = new NodoDecision(0, "Pedir");
        return raiz;
    }

    static String decidirDealer(NodoDecision nodo, int puntaje) {
        return (puntaje < nodo.valor) ? nodo.izq.accion : nodo.accion;
    }
    
    // Lista enlazada para baraja ========================================================
    static class NodoCarta {

        Carta carta;
        NodoCarta siguiente;

        NodoCarta(Carta carta) {
            this.carta = carta;
        }
    }

    static class Baraja {

        NodoCarta cabeza;

        public void agregarCarta(Carta carta) {
            NodoCarta nuevo = new NodoCarta(carta);
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
        }

        Carta robarCarta() {
            if (cabeza == null) {
                return null;
            }
            Carta c = cabeza.carta;
            cabeza = cabeza.siguiente;
            return c;
        }

        public void mezclar() {
            ArrayList<Carta> cartas = new ArrayList<>();
            while (cabeza != null) {
                cartas.add(robarCarta());
            }
            Collections.shuffle(cartas);
            for (Carta c : cartas) {
                agregarCarta(c);
            }
        }
    }

    JTextArea log;
    JButton pedirBtn, plantarseBtn;
    Jugador jugador = new Jugador();
    Jugador dealer = new Jugador();
    Baraja baraja = new Baraja();
    NodoDecision arbol;

    public Juego_visual() {
        super("Blackjack 21");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        log = new JTextArea();
        log.setEditable(false);
        JScrollPane scroll = new JScrollPane(log);

        pedirBtn = new JButton("Pedir Carta");
        plantarseBtn = new JButton("Plantarse");

        JPanel panelBotones = new JPanel();
        panelBotones.add(pedirBtn);
        panelBotones.add(plantarseBtn);

        add(scroll, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        pedirBtn.addActionListener(e -> pedirCarta());
        plantarseBtn.addActionListener(e -> dealerTurno());

        inicializarJuego();
    }

    public void inicializarJuego() {
        String nombre = JOptionPane.showInputDialog(this, "Ingrese su nombre:");
        jugador.nombre = nombre;
        dealer.nombre = "Dealer";

        for (Palo palo : Palo.values()) {
            for (Valor valor : Valor.values()) {
                baraja.agregarCarta(new Carta(valor, palo));
            }
        }
        baraja.mezclar();

        jugador.mano.add(baraja.robarCarta());
        jugador.mano.add(baraja.robarCarta());
        dealer.mano.add(baraja.robarCarta());
        dealer.mano.add(baraja.robarCarta());

        arbol = ArbolDecision();
        log.setText("Bienvenido a Blackjack\n\n");
        mostrarMano(jugador);
    }

    public void pedirCarta() {
        jugador.mano.add(baraja.robarCarta());
        mostrarMano(jugador);
        if (jugador.puntaje() > 21) {
            log.append("\nTe pasaste de 21. Pierdes.\n");
            pedirBtn.setEnabled(false);
            plantarseBtn.setEnabled(false);
        }
    }

    public void dealerTurno() {
        pedirBtn.setEnabled(false);
        plantarseBtn.setEnabled(false);
        log.append("\nTurno del Dealer\n");
        while (true) {
            int puntaje = dealer.puntaje();
            String accion = decidirDealer(arbol, puntaje);
            if (accion.equals("Pedir")) {
                dealer.mano.add(baraja.robarCarta());
                log.append("El dealer toma una carta...\n");
            } else {
                log.append("El dealer se planta.\n");
                break;
            }
        }
        mostrarMano(dealer);
        mostrarResultado();
    }

    void mostrarMano(Jugador j) {
        log.append("\n" + j.nombre + " tiene:\n");
        for (Carta c : j.mano) {
            log.append("  " + c + "\n");
        }
        log.append("Puntaje: " + j.puntaje() + "\n");
    }

    public void mostrarResultado() {
        int pj = jugador.puntaje();
        int pd = dealer.puntaje();
        if ((pj > pd && pj <= 21) || (pd > 21 && pj <= 21)) {
            log.append("\n" + jugador.nombre + " gana! 🎉\n");
        } else if (pj == pd) {
            log.append("\nEmpate.\n");
        } else {
            log.append("\nDealer gana.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Juego_visual().setVisible(true));
    }
}
